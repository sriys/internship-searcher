
import React from 'react';
import { Mail, ArrowRight, Zap, Target, Award, Users } from 'lucide-react';

interface LandingPageProps {
  onStart: () => void;
  onLogin: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onStart, onLogin }) => {
  return (
    <div className="bg-[#F8FAFC]">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center gap-2">
              <div className="bg-[#4F46E5] p-2 rounded-lg">
                <Mail className="text-white h-6 w-6" />
              </div>
              <span className="text-2xl font-bold text-[#0F172A] tracking-tight">INTMAIL</span>
            </div>
            <div className="hidden md:flex items-center gap-8 text-[#475569] font-medium">
              <a href="#features" className="hover:text-[#4F46E5] transition-colors">Features</a>
              <a href="#how-it-works" className="hover:text-[#4F46E5] transition-colors">How it Works</a>
              <button onClick={onLogin} className="hover:text-[#4F46E5] transition-colors">Login</button>
              <button 
                onClick={onStart}
                className="bg-[#4F46E5] text-white px-6 py-2.5 rounded-full hover:bg-[#4338CA] transition-all shadow-lg hover:shadow-[#4F46E5]/30"
              >
                Get Started
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-gradient-to-br from-indigo-100 to-transparent rounded-full blur-3xl opacity-50 -z-10"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              <h1 className="text-5xl lg:text-7xl font-extrabold text-[#0F172A] leading-tight mb-6">
                Write Cold Emails That <span className="text-[#4F46E5]">Get You</span> Internships.
              </h1>
              <p className="text-xl text-[#475569] mb-10 max-w-2xl mx-auto lg:mx-0">
                Generate professional, personalized internship emails in seconds using AI. Stand out from the crowd and land your dream role.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                <button 
                  onClick={onStart}
                  className="w-full sm:w-auto bg-[#FACC15] text-[#0F172A] font-bold px-8 py-4 rounded-full flex items-center justify-center gap-2 hover:bg-[#EAB308] transition-all transform hover:-translate-y-1 shadow-xl shadow-yellow-200"
                >
                  Generate Email <ArrowRight size={20} />
                </button>
                <button className="w-full sm:w-auto bg-white text-[#0F172A] border border-gray-200 font-bold px-8 py-4 rounded-full hover:bg-gray-50 transition-all">
                  View Demo
                </button>
              </div>
            </div>
            
            <div className="relative flex justify-center lg:justify-end">
              <div className="relative w-full max-w-lg animate-float">
                <div className="absolute inset-0 bg-indigo-500 rounded-2xl blur-2xl opacity-20 -rotate-6"></div>
                <div className="relative bg-white p-6 rounded-2xl shadow-2xl border border-gray-100">
                  <div className="flex gap-2 mb-4">
                    <div className="w-3 h-3 rounded-full bg-red-400"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
                    <div className="w-3 h-3 rounded-full bg-green-400"></div>
                  </div>
                  <div className="space-y-4">
                    <div className="h-4 bg-gray-100 rounded w-3/4"></div>
                    <div className="h-4 bg-gray-100 rounded w-1/2"></div>
                    <div className="h-4 bg-indigo-50 rounded w-full"></div>
                    <div className="h-4 bg-indigo-50 rounded w-full"></div>
                    <div className="h-4 bg-indigo-50 rounded w-5/6"></div>
                    <div className="h-10 bg-[#4F46E5]/10 rounded-lg w-32 ml-auto"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[#0F172A] mb-4">Powerful Features for Modern Students</h2>
            <p className="text-lg text-[#475569]">Everything you need to bypass the "Apply" button and get noticed.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Zap className="text-[#4F46E5]" />}
              title="Instant Generation"
              description="Input your details once and generate tailored emails for any company in seconds."
            />
            <FeatureCard 
              icon={<Target className="text-[#4F46E5]" />}
              title="Tailored for HR"
              description="AI models trained on successful cold outreach strategies used by top-tier interns."
            />
            <FeatureCard 
              icon={<Award className="text-[#4F46E5]" />}
              title="Multiple Tones"
              description="Choose between Startup, Friendly, or Professional tones to match the company culture."
            />
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="how-it-works" className="py-24 bg-[#F8FAFC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[#0F172A] mb-4">How it Works</h2>
          </div>
          
          <div className="flex flex-col md:flex-row items-center justify-between gap-12">
            <Step number="1" title="Add Your Profile" desc="Share your skills, projects, and educational background." />
            <div className="hidden md:block h-px bg-gray-200 flex-1"></div>
            <Step number="2" title="Pick a Company" desc="Tell us which role and company you're targeting." />
            <div className="hidden md:block h-px bg-gray-200 flex-1"></div>
            <Step number="3" title="Generate & Send" desc="Get a high-conversion email ready to copy and paste." />
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-[#0F172A] mb-12">Trusted by students at top universities</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Testimonial author="Sarah K." role="Software Intern @ Meta" text="INTMAIL changed how I apply. I got 3 interviews in a week after using it." />
            <Testimonial author="James L." role="Product Intern @ Google" text="The personalization is incredible. Recruiters actually reply thinking I wrote it from scratch." />
            <Testimonial author="Ananya R." role="Marketing Intern @ Nike" text="Finally, an AI that understands the student struggle. Highly recommended!" />
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="py-20">
        <div className="max-w-5xl mx-auto px-4">
          <div className="bg-[#0F172A] rounded-3xl p-12 text-center text-white relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 right-0 p-8 opacity-10">
              <Mail size={120} />
            </div>
            <h2 className="text-4xl font-bold mb-6">Stop Sending Generic Applications.</h2>
            <p className="text-xl text-gray-400 mb-10">Join thousands of students landing dream internships with INTMAIL.</p>
            <button 
              onClick={onStart}
              className="bg-[#FACC15] text-[#0F172A] font-bold px-10 py-4 rounded-full hover:bg-[#EAB308] transition-all transform hover:scale-105"
            >
              Start Generating Now
            </button>
          </div>
        </div>
      </section>

      <footer className="py-12 border-t border-gray-200 text-center text-[#475569]">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Mail className="h-5 w-5 text-[#4F46E5]" />
          <span className="font-bold text-[#0F172A]">INTMAIL</span>
        </div>
        <p>&copy; 2024 INTMAIL. All rights reserved.</p>
      </footer>
    </div>
  );
};

const FeatureCard: React.FC<{ icon: React.ReactNode; title: string; description: string }> = ({ icon, title, description }) => (
  <div className="p-8 rounded-2xl border border-gray-100 hover:border-indigo-100 hover:shadow-xl transition-all group bg-[#F8FAFC]">
    <div className="bg-white p-4 rounded-xl shadow-sm mb-6 inline-block transform group-hover:-translate-y-1 transition-transform">
      {icon}
    </div>
    <h3 className="text-xl font-bold text-[#0F172A] mb-3">{title}</h3>
    <p className="text-[#475569]">{description}</p>
  </div>
);

const Step: React.FC<{ number: string; title: string; desc: string }> = ({ number, title, desc }) => (
  <div className="text-center flex-1">
    <div className="w-12 h-12 bg-[#4F46E5] text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-6">
      {number}
    </div>
    <h3 className="text-xl font-bold text-[#0F172A] mb-2">{title}</h3>
    <p className="text-[#475569]">{desc}</p>
  </div>
);

const Testimonial: React.FC<{ author: string; role: string; text: string }> = ({ author, role, text }) => (
  <div className="bg-[#F8FAFC] p-8 rounded-2xl text-left border border-gray-50">
    <div className="flex gap-1 text-yellow-400 mb-4">
      {[...Array(5)].map((_, i) => <Award key={i} size={16} fill="currentColor" />)}
    </div>
    <p className="text-[#475569] mb-6 italic">"{text}"</p>
    <div>
      <h4 className="font-bold text-[#0F172A]">{author}</h4>
      <p className="text-sm text-[#4F46E5]">{role}</p>
    </div>
  </div>
);
