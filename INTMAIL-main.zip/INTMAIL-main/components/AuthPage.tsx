
import React, { useState } from 'react';
import { Mail, ChevronLeft } from 'lucide-react';

interface AuthPageProps {
  onAuth: (email: string) => void;
  onBack: () => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ onAuth, onBack }) => {
  const [email, setEmail] = useState('');
  const [isLogin, setIsLogin] = useState(true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) onAuth(email);
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Left side: Branding/Quote */}
      <div className="hidden md:flex flex-1 bg-[#0F172A] p-12 flex-col justify-between text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500 rounded-full blur-[120px] opacity-20 -translate-y-1/2 translate-x-1/2"></div>
        <button onClick={onBack} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors z-10">
          <ChevronLeft size={20} /> Back to Home
        </button>
        
        <div className="z-10">
          <h2 className="text-5xl font-bold leading-tight mb-6 font-heading">
            Your internship journey <span className="text-indigo-400">starts here.</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-md">
            Stop waiting for HR to find you. Take the lead with perfectly crafted outreach.
          </p>
        </div>

        <div className="z-10 bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-md">
          <p className="text-indigo-300 italic mb-4">"The cold email I sent using INTMAIL got me an interview at a Fortune 500 within 24 hours."</p>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-indigo-500 flex items-center justify-center font-bold">JD</div>
            <div>
              <p className="font-bold">John Doe</p>
              <p className="text-sm text-gray-400">CS Junior, Stanford</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right side: Form */}
      <div className="flex-1 bg-[#F8FAFC] flex items-center justify-center p-6 md:p-12">
        <div className="w-full max-w-md">
          <div className="md:hidden flex items-center gap-2 mb-8" onClick={onBack}>
             <Mail className="h-6 w-6 text-[#4F46E5]" />
             <span className="font-bold text-xl text-[#0F172A]">INTMAIL</span>
          </div>

          <div className="bg-white p-10 rounded-3xl shadow-xl shadow-gray-200/50 border border-gray-100">
            <h1 className="text-3xl font-bold text-[#0F172A] mb-2">{isLogin ? 'Welcome Back' : 'Create Account'}</h1>
            <p className="text-[#475569] mb-8">{isLogin ? 'Sign in to your account' : 'Start your journey today'}</p>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-[#0F172A] mb-2">Email Address</label>
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@university.edu"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#4F46E5]/20 focus:border-[#4F46E5] transition-all"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-[#0F172A] mb-2">Password</label>
                <input 
                  type="password" 
                  placeholder="••••••••"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#4F46E5]/20 focus:border-[#4F46E5] transition-all"
                  required
                />
              </div>

              <button 
                type="submit"
                className="w-full bg-[#4F46E5] text-white font-bold py-4 rounded-xl hover:bg-[#4338CA] transition-all shadow-lg shadow-indigo-200"
              >
                {isLogin ? 'Log In' : 'Sign Up'}
              </button>
            </form>

            <div className="mt-8 relative">
              <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-100"></div></div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-400">Or continue with</span>
              </div>
            </div>

            <button className="mt-8 w-full flex items-center justify-center gap-3 border border-gray-200 py-3 rounded-xl hover:bg-gray-50 transition-all font-medium text-[#475569]">
              <svg className="w-5 h-5" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
              Google
            </button>

            <p className="mt-8 text-center text-sm text-[#475569]">
              {isLogin ? "Don't have an account?" : "Already have an account?"}
              <button 
                onClick={() => setIsLogin(!isLogin)}
                className="ml-1 text-[#4F46E5] font-bold hover:underline"
              >
                {isLogin ? 'Sign up' : 'Log in'}
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
