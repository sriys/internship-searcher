
import React, { useState, useEffect, useRef } from 'react';
import { 
  PlusCircle, History, Star, User, LogOut, 
  Menu, X, Moon, Sun, Search, 
  Mail, Copy, Trash2, Download, Save, Check, Edit,
  ArrowRight, Sparkles, Send, Tag, Briefcase, GraduationCap
} from 'lucide-react';
import { AppView, EmailFormData, GeneratedEmail, Tone, Length } from '../types.ts';
import { generateColdEmail } from '../services/geminiService.ts';

interface DashboardProps {
  view: AppView;
  setView: (v: AppView) => void;
  user: { name: string; email: string } | null;
  onLogout: () => void;
  history: GeneratedEmail[];
  setHistory: (h: GeneratedEmail[]) => void;
  addToast: (msg: string, type?: 'success' | 'info') => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ view, setView, user, onLogout, history, setHistory, addToast }) => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [isDarkMode, setDarkMode] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedResult, setGeneratedResult] = useState<{ subject: string; body: string } | null>(null);
  const [displayedBody, setDisplayedBody] = useState('');
  const [formData, setFormData] = useState<EmailFormData>({
    studentName: user?.name || '',
    degree: '',
    college: '',
    skills: '',
    projects: '',
    companyName: '',
    role: '',
    interest: '',
    tone: 'Professional',
    length: 'Medium'
  });

  // Handle typing effect for AI results
  useEffect(() => {
    if (generatedResult && isGenerating === false) {
      let i = 0;
      setDisplayedBody('');
      const interval = setInterval(() => {
        setDisplayedBody((prev) => prev + generatedResult.body[i]);
        i++;
        if (i === generatedResult.body.length) clearInterval(interval);
      }, 5);
      return () => clearInterval(interval);
    }
  }, [generatedResult, isGenerating]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);
    setGeneratedResult(null);
    setDisplayedBody('');
    
    try {
      const result = await generateColdEmail(formData);
      setGeneratedResult(result);
      
      const newEntry: GeneratedEmail = {
        id: Date.now().toString(),
        subject: result.subject,
        body: result.body,
        company: formData.companyName,
        role: formData.role,
        date: new Date().toLocaleDateString(),
        isSaved: false
      };
      setHistory([newEntry, ...history]);
      addToast('Email generated successfully!');
    } catch (err) {
      addToast('Failed to generate email. Try again.', 'info');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = (subject?: string, body?: string) => {
    const s = subject || generatedResult?.subject;
    const b = body || generatedResult?.body;
    if (!s || !b) return;
    const text = `Subject: ${s}\n\n${b}`;
    navigator.clipboard.writeText(text);
    addToast('Copied to clipboard');
  };

  const handleDownloadPDF = (subject?: string, body?: string, company?: string) => {
    const s = subject || generatedResult?.subject;
    const b = body || generatedResult?.body;
    const c = company || formData.companyName || "Company";
    
    if (!s || !b) return;

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const html = `
      <html>
        <head>
          <title>INTMAIL - ${c} Outreach</title>
          <style>
            body { font-family: 'Inter', sans-serif; padding: 40px; color: #1a202c; line-height: 1.6; }
            .header { border-bottom: 2px solid #4f46e5; padding-bottom: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
            .logo { color: #4f46e5; font-weight: bold; font-size: 24px; }
            .meta { color: #718096; font-size: 12px; }
            .subject { font-weight: bold; margin-bottom: 20px; font-size: 18px; color: #2d3748; }
            .body { white-space: pre-line; font-size: 14px; }
            @media print { .no-print { display: none; } }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="logo">INTMAIL</div>
            <div class="meta">Generated for ${user?.name || 'User'} on ${new Date().toLocaleDateString()}</div>
          </div>
          <div class="subject">Subject: ${s}</div>
          <div class="body">${b}</div>
          <script>
            window.onload = function() { window.print(); window.close(); }
          </script>
        </body>
      </html>
    `;
    printWindow.document.write(html);
    printWindow.document.close();
    addToast('PDF ready for saving', 'success');
  };

  const toggleSave = (id: string) => {
    const newHistory = history.map(item => item.id === id ? { ...item, isSaved: !item.isSaved } : item);
    setHistory(newHistory);
    const item = newHistory.find(x => x.id === id);
    addToast(item?.isSaved ? 'Saved to collection' : 'Removed from collection');
  };

  const deleteItem = (id: string) => {
    setHistory(history.filter(item => item.id !== id));
    addToast('Entry deleted', 'info');
  };

  return (
    <div className={`flex min-h-screen ${isDarkMode ? 'bg-[#0B0F1A] text-white' : 'bg-[#F8FAFC] text-[#0F172A]'} transition-colors duration-300`}>
      {/* Sidebar Overlay (Mobile) */}
      {isSidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-20 lg:hidden backdrop-blur-sm" onClick={() => setSidebarOpen(false)}></div>
      )}

      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 w-72 bg-[#0F172A] transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 lg:static transition-transform duration-500 ease-out z-30 flex flex-col`}>
        <div className="p-8 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-[#4F46E5] p-2.5 rounded-xl shadow-lg shadow-indigo-500/20">
              <Mail className="text-white h-6 w-6" />
            </div>
            <span className="text-2xl font-bold text-white tracking-tight font-heading">INTMAIL</span>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-gray-400 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>

        <nav className="flex-1 px-4 py-8 space-y-2">
          <SidebarItem icon={<PlusCircle size={22} />} label="New Email" active={view === 'DASHBOARD'} onClick={() => setView('DASHBOARD')} />
          <SidebarItem icon={<History size={22} />} label="History" active={view === 'HISTORY'} onClick={() => setView('HISTORY')} />
          <SidebarItem icon={<Star size={22} />} label="Saved" active={view === 'SAVED'} onClick={() => setView('SAVED')} />
          <div className="pt-4 pb-2 px-4"><div className="h-px bg-white/5"></div></div>
          <SidebarItem icon={<User size={22} />} label="Profile" active={view === 'PROFILE'} onClick={() => setView('PROFILE')} />
        </nav>

        <div className="p-6">
          <div className="bg-white/5 rounded-2xl p-4 mb-4 border border-white/10">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Status</p>
            <p className="text-sm font-medium text-green-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span> Free Plan Active
            </p>
          </div>
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3.5 text-gray-400 hover:text-red-400 hover:bg-red-400/10 rounded-xl transition-all font-medium"
          >
            <LogOut size={20} /> <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Header */}
        <header className={`flex items-center justify-between px-8 py-5 border-b ${isDarkMode ? 'border-white/5 bg-[#0B0F1A]/80' : 'border-gray-200 bg-white/80'} backdrop-blur-xl sticky top-0 z-10`}>
          <div className="flex items-center gap-4">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <Menu size={22} />
            </button>
            <div className="hidden sm:block">
              <h1 className="text-lg font-bold text-[#0F172A] dark:text-white">
                {view === 'DASHBOARD' ? 'Create Outreach' : view === 'HISTORY' ? 'Application History' : view}
              </h1>
              <p className="text-xs text-gray-400 font-medium">Empowering your career journey</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input 
                type="text" 
                placeholder="Find emails..."
                className={`pl-10 pr-4 py-2.5 rounded-xl text-sm w-64 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-gray-50 border-gray-100'}`}
              />
            </div>
            <button 
              onClick={() => setDarkMode(!isDarkMode)}
              className={`p-2.5 rounded-xl border transition-all ${isDarkMode ? 'border-white/10 hover:bg-white/5' : 'border-gray-100 hover:bg-gray-50'}`}
            >
              {isDarkMode ? <Sun size={20} className="text-[#FACC15]" /> : <Moon size={20} className="text-[#4F46E5]" />}
            </button>
            <div className="flex items-center gap-3 pl-2 border-l border-gray-100 dark:border-white/10">
               <div className="text-right hidden sm:block">
                 <p className="text-sm font-bold truncate max-w-[100px]">{user?.name}</p>
                 <p className="text-[10px] text-gray-400 uppercase font-bold tracking-tighter">Student</p>
               </div>
               <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold shadow-lg shadow-indigo-500/30">
                {user?.name?.[0]?.toUpperCase()}
              </div>
            </div>
          </div>
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 md:p-10 custom-scrollbar">
          {view === 'DASHBOARD' && (
            <div className="grid xl:grid-cols-12 gap-10">
              {/* Form Side */}
              <div className="xl:col-span-7 space-y-8 animate-[fadeIn_0.5s_ease-out]">
                <div className={`p-8 md:p-10 rounded-[2.5rem] shadow-2xl border ${isDarkMode ? 'bg-white/5 border-white/10 shadow-black/20' : 'bg-white border-gray-100 shadow-indigo-100/50'}`}>
                  <div className="flex items-center gap-3 mb-8">
                    <div className="w-1.5 h-8 bg-indigo-500 rounded-full"></div>
                    <h2 className="text-3xl font-extrabold font-heading tracking-tight">Email Details</h2>
                  </div>

                  <form onSubmit={handleGenerate} className="space-y-8">
                    <section>
                      <h3 className="text-xs font-black text-indigo-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <GraduationCap size={14} /> Personal Profile
                      </h3>
                      <div className="grid md:grid-cols-2 gap-6">
                        <InputGroup label="Degree / Major" icon={<GraduationCap size={16} />} value={formData.degree} onChange={(v) => setFormData({...formData, degree: v})} placeholder="B.S. in Computer Science" />
                        <InputGroup label="University" icon={<GraduationCap size={16} />} value={formData.college} onChange={(v) => setFormData({...formData, college: v})} placeholder="State Institute of Tech" />
                      </div>
                      <div className="mt-6">
                        <InputGroup label="Skills & Expertise" icon={<Tag size={16} />} value={formData.skills} onChange={(v) => setFormData({...formData, skills: v})} placeholder="React, Python, Figma, SQL..." />
                      </div>
                    </section>

                    <section>
                      <h3 className="text-xs font-black text-indigo-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <Briefcase size={14} /> Target Opportunity
                      </h3>
                      <div className="grid md:grid-cols-2 gap-6">
                        <InputGroup label="Company Name" icon={<Briefcase size={16} />} value={formData.companyName} onChange={(v) => setFormData({...formData, companyName: v})} placeholder="e.g. OpenAI" />
                        <InputGroup label="Desired Role" icon={<ArrowRight size={16} />} value={formData.role} onChange={(v) => setFormData({...formData, role: v})} placeholder="Product Management Intern" />
                      </div>
                      <div className="mt-6">
                        <label className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2 block">Why are you interested?</label>
                        <textarea 
                          rows={4}
                          value={formData.interest}
                          onChange={(e) => setFormData({...formData, interest: e.target.value})}
                          placeholder="What excites you about this specific company or team?"
                          className={`w-full px-5 py-4 rounded-2xl border transition-all resize-none focus:ring-4 focus:ring-indigo-500/10 focus:outline-none ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-gray-50 border-gray-100 hover:border-indigo-200'}`}
                          required 
                        />
                      </div>
                    </section>

                    <section className="bg-indigo-50/50 dark:bg-white/5 p-6 rounded-3xl border border-indigo-100 dark:border-white/10">
                      <div className="grid grid-cols-2 gap-6">
                        <div>
                          <label className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2 block">Writing Tone</label>
                          <select 
                            value={formData.tone}
                            onChange={(e) => setFormData({...formData, tone: e.target.value as Tone})}
                            className={`w-full px-5 py-3.5 rounded-xl border transition-all focus:outline-none font-bold text-sm ${isDarkMode ? 'bg-[#0F172A] border-white/10' : 'bg-white border-gray-200 shadow-sm'}`}
                          >
                            <option>Professional</option>
                            <option>Friendly</option>
                            <option>Startup</option>
                          </select>
                        </div>
                        <div>
                          <label className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2 block">Length</label>
                          <select 
                            value={formData.length}
                            onChange={(e) => setFormData({...formData, length: e.target.value as Length})}
                            className={`w-full px-5 py-3.5 rounded-xl border transition-all focus:outline-none font-bold text-sm ${isDarkMode ? 'bg-[#0F172A] border-white/10' : 'bg-white border-gray-200 shadow-sm'}`}
                          >
                            <option>Short</option>
                            <option>Medium</option>
                          </select>
                        </div>
                      </div>
                    </section>

                    <button 
                      type="submit"
                      disabled={isGenerating}
                      className="w-full bg-[#4F46E5] text-white font-black py-5 rounded-2xl flex items-center justify-center gap-3 hover:bg-[#4338CA] transition-all transform hover:-translate-y-1 shadow-xl shadow-indigo-500/30 disabled:opacity-50 disabled:transform-none group"
                    >
                      {isGenerating ? (
                        <div className="flex gap-1.5 items-center">
                          <span className="shimmer h-2 w-2 rounded-full bg-white/40"></span>
                          <span className="animate-pulse">Analyzing Profile...</span>
                        </div>
                      ) : (
                        <>
                          <Sparkles className="group-hover:rotate-12 transition-transform" size={20} /> 
                          Craft My Email
                        </>
                      )}
                    </button>
                  </form>
                </div>
              </div>

              {/* Result Side */}
              <div className="xl:col-span-5 space-y-8 animate-[fadeIn_0.5s_ease-out_0.2s_both]">
                <div className={`p-8 rounded-[2.5rem] shadow-2xl border min-h-[600px] flex flex-col relative overflow-hidden ${isDarkMode ? 'bg-[#151B2B] border-white/10 shadow-black/40' : 'bg-white border-indigo-50 shadow-indigo-100/30'}`}>
                  {isGenerating && (
                    <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-white/90 dark:bg-black/90 backdrop-blur-sm">
                       <div className="relative">
                          <div className="w-24 h-24 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin"></div>
                          <Sparkles className="absolute inset-0 m-auto text-indigo-500 animate-pulse" size={32} />
                       </div>
                       <p className="mt-6 font-bold text-lg animate-pulse">Generating your masterpiece...</p>
                       <p className="text-sm text-gray-400 mt-2 italic px-8 text-center">Tuning into {formData.companyName}'s vibe...</p>
                    </div>
                  )}

                  {generatedResult ? (
                    <div className="flex flex-col h-full animate-[fadeIn_0.3s_ease-out]">
                      <div className="flex justify-between items-center mb-8">
                        <div className="flex items-center gap-3">
                          <div className="bg-indigo-50 dark:bg-indigo-500/20 p-2 rounded-lg">
                            <Send className="text-indigo-500 h-5 w-5" />
                          </div>
                          <div>
                            <h3 className="font-black text-[#0F172A] dark:text-white leading-tight">Draft Ready</h3>
                            <p className="text-[10px] text-gray-400 uppercase font-bold">Optimized for conversion</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                           <button onClick={() => handleCopy()} className={`p-3 rounded-xl transition-all shadow-sm ${isDarkMode ? 'bg-white/5 border-white/10 hover:bg-white/10' : 'bg-gray-50 border-gray-100 hover:bg-white hover:shadow-md'}`}>
                             <Copy size={18} className="text-indigo-500" />
                           </button>
                           <button onClick={() => toggleSave('new')} className={`p-3 rounded-xl transition-all shadow-sm ${isDarkMode ? 'bg-white/5 border-white/10 hover:bg-white/10' : 'bg-gray-50 border-gray-100 hover:bg-white hover:shadow-md'}`}>
                             <Star size={18} className="text-yellow-500" />
                           </button>
                        </div>
                      </div>
                      
                      <div className="space-y-6 flex-1 overflow-y-auto custom-scrollbar pr-2">
                        <div className={`p-5 rounded-2xl border ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-indigo-50/30 border-indigo-100/50'}`}>
                           <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-1">Subject Line</p>
                           <p className="font-bold text-sm">{generatedResult.subject}</p>
                        </div>
                        <div className={`text-sm leading-relaxed whitespace-pre-line font-medium ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                           {displayedBody}
                           {displayedBody.length < generatedResult.body.length && <span className="w-1.5 h-4 bg-indigo-500 inline-block ml-1 animate-pulse"></span>}
                        </div>
                      </div>

                      <div className="mt-8 pt-8 border-t border-gray-100 dark:border-white/10">
                        <div className="grid grid-cols-2 gap-4">
                           <button 
                             onClick={() => handleDownloadPDF()}
                             className="flex items-center justify-center gap-2 bg-[#FACC15] text-[#0F172A] font-black py-4 rounded-2xl hover:bg-[#EAB308] transition-all transform hover:-translate-y-1 shadow-lg shadow-yellow-200 dark:shadow-none"
                           >
                              <Download size={18} /> Download PDF
                           </button>
                           <button onClick={() => setGeneratedResult(null)} className={`flex items-center justify-center gap-2 font-bold py-4 rounded-2xl border transition-all ${isDarkMode ? 'border-white/10 hover:bg-white/5' : 'border-gray-200 bg-gray-50 hover:bg-white hover:shadow-md text-gray-500'}`}>
                              Redraft
                           </button>
                        </div>
                        <p className="text-center text-[10px] text-gray-400 mt-4 font-bold uppercase tracking-widest">Confidence Score: 98%</p>
                      </div>
                    </div>
                  ) : (
                    <div className="flex-1 flex flex-col items-center justify-center text-center p-10 animate-pulse">
                       <div className="w-24 h-24 bg-indigo-50 dark:bg-white/5 rounded-full flex items-center justify-center mb-8 relative">
                         <div className="absolute inset-0 rounded-full border border-indigo-500/20 scale-150 animate-ping"></div>
                         <Mail className="text-indigo-200 dark:text-indigo-500/20" size={48} />
                       </div>
                       <h3 className="text-2xl font-black mb-4">Your Inbox Awaits</h3>
                       <p className="text-gray-400 font-medium leading-relaxed max-w-xs mx-auto">
                         Fill in your career details and let our AI craft a personalized outreach message that recruiters can't ignore.
                       </p>
                       <div className="mt-10 flex gap-1.5">
                          <div className="w-2 h-2 rounded-full bg-indigo-100 dark:bg-white/10"></div>
                          <div className="w-2 h-2 rounded-full bg-indigo-200 dark:bg-white/20"></div>
                          <div className="w-2 h-2 rounded-full bg-indigo-300 dark:bg-white/30"></div>
                       </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {(view === 'HISTORY' || view === 'SAVED') && (
            <div className="space-y-10 animate-[fadeIn_0.5s_ease-out]">
              <div className="flex flex-col md:flex-row justify-between md:items-end gap-6 border-b border-gray-100 dark:border-white/10 pb-10">
                <div>
                  <h2 className="text-4xl font-black font-heading mb-2 tracking-tight">
                    {view === 'HISTORY' ? 'Application Vault' : 'Saved Collection'}
                  </h2>
                  <p className="text-gray-400 font-medium">Tracking your journey across {new Set(history.map(x=>x.company)).size} companies</p>
                </div>
                <div className="flex items-center gap-4">
                   <div className="relative group">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4 transition-colors group-focus-within:text-indigo-500" />
                      <input 
                        className={`pl-11 pr-5 py-3.5 border transition-all rounded-2xl w-full md:w-80 focus:ring-4 focus:ring-indigo-500/10 focus:outline-none focus:border-indigo-500 ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white border-gray-200 shadow-sm'}`} 
                        placeholder="Search by company or role..." 
                      />
                   </div>
                </div>
              </div>

              {history.filter(h => view === 'HISTORY' ? true : h.isSaved).length > 0 ? (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
                  {history
                    .filter(h => view === 'HISTORY' ? true : h.isSaved)
                    .map((item, idx) => (
                      <HistoryCard 
                        key={item.id} 
                        item={item} 
                        index={idx}
                        onToggleSave={() => toggleSave(item.id)}
                        onDelete={() => deleteItem(item.id)}
                        isDarkMode={isDarkMode}
                        onCopy={() => handleCopy(item.subject, item.body)}
                        onDownload={() => handleDownloadPDF(item.subject, item.body, item.company)}
                      />
                    ))}
                </div>
              ) : (
                <div className="text-center py-32 flex flex-col items-center">
                  <div className="bg-gray-100 dark:bg-white/5 w-24 h-24 rounded-[2rem] flex items-center justify-center mb-8 rotate-12 transition-transform hover:rotate-0 cursor-default">
                    <History size={48} className="text-gray-300 dark:text-gray-600" />
                  </div>
                  <h3 className="text-3xl font-black text-gray-300 dark:text-gray-700">Empty Vault</h3>
                  <p className="text-gray-400 font-medium mt-2">Your history will appear once you generate your first email.</p>
                  <button onClick={() => setView('DASHBOARD')} className="mt-8 bg-indigo-500 text-white px-8 py-3.5 rounded-2xl font-bold hover:bg-indigo-600 transition-all">
                    Start Now
                  </button>
                </div>
              )}
            </div>
          )}

          {view === 'PROFILE' && (
             <div className="max-w-3xl mx-auto py-10 animate-[fadeIn_0.5s_ease-out]">
                <div className={`p-10 md:p-14 rounded-[3rem] border shadow-2xl ${isDarkMode ? 'bg-[#151B2B] border-white/10 shadow-black/20' : 'bg-white border-gray-100 shadow-indigo-100/30'}`}>
                   <div className="flex flex-col items-center mb-12">
                      <div className="relative group">
                        <div className="absolute -inset-1 bg-gradient-to-tr from-indigo-500 to-purple-500 rounded-[2.5rem] blur opacity-30 group-hover:opacity-60 transition-opacity"></div>
                        <div className="relative w-32 h-32 bg-[#4F46E5] rounded-[2.2rem] flex items-center justify-center text-white text-5xl font-black shadow-xl">
                           {user?.name?.[0]?.toUpperCase()}
                        </div>
                      </div>
                      <h2 className="text-3xl font-black mt-8 mb-1">{user?.name}</h2>
                      <div className="flex items-center gap-2 text-gray-400 font-bold text-sm uppercase tracking-widest">
                        <Sparkles size={14} className="text-[#FACC15]" /> Explorer Tier
                      </div>
                      <p className="mt-4 text-indigo-500 font-bold">{user?.email}</p>
                   </div>

                   <div className="grid md:grid-cols-2 gap-6 mb-12">
                      <ProfileStat label="Generated" value={history.length} icon={<Mail className="text-indigo-500" />} />
                      <ProfileStat label="Saved Items" value={history.filter(x=>x.isSaved).length} icon={<Star className="text-yellow-500" />} />
                   </div>

                   <div className="space-y-6">
                      <div className={`flex items-center justify-between p-6 rounded-3xl border transition-all ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-gray-50 border-gray-200'}`}>
                         <div className="flex items-center gap-5">
                            <div className={`p-4 rounded-2xl ${isDarkMode ? 'bg-white/10' : 'bg-white shadow-sm'}`}><GraduationCap size={24} className="text-indigo-500" /></div>
                            <div>
                               <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Education</p>
                               <p className="font-bold">Not Configured</p>
                            </div>
                         </div>
                         <button className="text-indigo-500 text-sm font-black hover:underline px-4">Complete</button>
                      </div>
                   </div>

                   <div className="mt-12 pt-10 border-t border-gray-100 dark:border-white/10 grid grid-cols-2 gap-4">
                      <button className="bg-indigo-500 text-white font-black py-4 rounded-2xl hover:bg-indigo-600 transition-all shadow-lg shadow-indigo-500/20">
                        Update Portfolio
                      </button>
                      <button 
                        onClick={onLogout}
                        className="border border-red-500/20 text-red-500 font-black py-4 rounded-2xl hover:bg-red-500 hover:text-white transition-all"
                      >
                        Sign Out
                      </button>
                   </div>
                </div>
             </div>
          )}
        </div>
      </main>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #E2E8F0;
          border-radius: 10px;
        }
        .custom-scrollbar:hover::-webkit-scrollbar-thumb {
          background: #CBD5E1;
        }
        .dark .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #1E293B;
        }
      `}</style>
    </div>
  );
};

const SidebarItem: React.FC<{ icon: React.ReactNode; label: string; active?: boolean; onClick: () => void }> = ({ icon, label, active, onClick }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all font-bold text-sm tracking-tight ${active ? 'bg-[#4F46E5] text-white shadow-xl shadow-indigo-900/50 scale-[1.02]' : 'text-gray-500 hover:text-white hover:bg-white/5'}`}
  >
    {icon} <span>{label}</span>
  </button>
);

const HistoryCard: React.FC<{ 
  item: GeneratedEmail; 
  index: number; 
  onToggleSave: () => void; 
  onDelete: () => void; 
  isDarkMode: boolean;
  onCopy: () => void;
  onDownload: () => void;
}> = ({ item, index, onToggleSave, onDelete, isDarkMode, onCopy, onDownload }) => (
  <div 
    className={`p-8 rounded-[2rem] border transition-all hover:shadow-2xl hover:-translate-y-2 group flex flex-col justify-between h-[340px] ${isDarkMode ? 'bg-white/5 border-white/10 hover:bg-white/10' : 'bg-white border-gray-100 hover:border-indigo-100 shadow-sm'}`}
    style={{ animation: `fadeIn 0.5s ease-out ${index * 0.1}s both` }}
  >
    <div>
      <div className="flex justify-between items-start mb-6">
        <div className={`px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest ${isDarkMode ? 'bg-indigo-500/20 text-indigo-300' : 'bg-indigo-50 text-indigo-600'}`}>
          {item.company}
        </div>
        <div className="flex gap-1 group-hover:opacity-100 transition-opacity">
          <button onClick={onToggleSave} className={`p-2 rounded-xl transition-all ${item.isSaved ? 'text-yellow-500 bg-yellow-50' : 'text-gray-300 hover:bg-gray-100 hover:text-yellow-500'}`}>
            <Star size={18} fill={item.isSaved ? "currentColor" : "none"} />
          </button>
          <button onClick={onDelete} className="p-2 rounded-xl text-gray-300 hover:text-red-500 hover:bg-red-50 transition-all">
            <Trash2 size={18} />
          </button>
        </div>
      </div>
      <h3 className="text-xl font-black mb-1 truncate font-heading">{item.role}</h3>
      <div className="flex items-center gap-2 text-[10px] text-gray-400 font-bold uppercase tracking-tight mb-5">
        <History size={12} /> {item.date}
      </div>
      <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-4 font-medium leading-relaxed italic border-l-2 border-indigo-100 dark:border-white/10 pl-4">
        {item.body}
      </p>
    </div>
    <div className="mt-6 flex gap-2">
      <button 
        onClick={onCopy}
        className={`flex-1 py-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 ${isDarkMode ? 'bg-white/5 hover:bg-white/10' : 'bg-gray-50 text-gray-600 hover:bg-indigo-500 hover:text-white shadow-sm'}`}
      >
        <Copy size={14} /> Copy
      </button>
      <button 
        onClick={onDownload}
        className={`p-3 rounded-xl transition-all ${isDarkMode ? 'bg-white/5 hover:bg-white/10' : 'bg-gray-50 text-indigo-500 hover:bg-indigo-500 hover:text-white'}`}
      >
        <Download size={16} />
      </button>
    </div>
  </div>
);

const InputGroup: React.FC<{ label: string; icon: React.ReactNode; value: string; onChange: (v: string) => void; placeholder: string }> = ({ label, icon, value, onChange, placeholder }) => {
  const isDarkMode = document.documentElement.classList.contains('dark');
  return (
    <div>
      <label className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2 block">{label}</label>
      <div className="relative group">
        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-indigo-500 transition-colors">
          {icon}
        </div>
        <input 
          type="text" 
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className={`w-full pl-11 pr-5 py-4 rounded-2xl border transition-all focus:ring-4 focus:ring-indigo-500/10 focus:outline-none focus:border-indigo-500 font-medium ${isDarkMode ? 'bg-white/5 border-white/10 placeholder:text-gray-600' : 'bg-gray-50 border-gray-100 hover:border-indigo-200'}`}
          required 
        />
      </div>
    </div>
  );
};

const ProfileStat: React.FC<{ label: string; value: number | string; icon: React.ReactNode }> = ({ label, value, icon }) => (
  <div className="p-6 rounded-[2rem] border border-gray-100 dark:border-white/10 flex flex-col items-center text-center bg-gray-50 dark:bg-white/5">
    <div className="mb-4 bg-white dark:bg-[#0F172A] p-3 rounded-2xl shadow-sm">{icon}</div>
    <p className="text-3xl font-black mb-1">{value}</p>
    <p className="text-xs font-black text-gray-400 uppercase tracking-widest">{label}</p>
  </div>
);
