
export type Tone = 'Professional' | 'Friendly' | 'Startup';
export type Length = 'Short' | 'Medium';

export interface EmailFormData {
  studentName: string;
  degree: string;
  college: string;
  skills: string;
  projects: string;
  companyName: string;
  role: string;
  hrName?: string;
  interest: string;
  tone: Tone;
  length: Length;
}

export interface GeneratedEmail {
  id: string;
  subject: string;
  body: string;
  company: string;
  role: string;
  date: string;
  isSaved?: boolean;
}

export type AppView = 'LANDING' | 'AUTH' | 'DASHBOARD' | 'HISTORY' | 'SAVED' | 'PROFILE';
