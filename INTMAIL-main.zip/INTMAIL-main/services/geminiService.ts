
import { GoogleGenAI, Type } from "@google/genai";
import { EmailFormData } from "../types.ts";

export const generateColdEmail = async (data: EmailFormData): Promise<{ subject: string; body: string }> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
  
  const prompt = `
    Generate a highly personalized cold email for an internship application.
    
    Student Details:
    - Name: ${data.studentName}
    - Degree & College: ${data.degree} at ${data.college}
    - Skills: ${data.skills}
    - Key Projects: ${data.projects}
    
    Target Details:
    - Company: ${data.companyName}
    - Role: ${data.role}
    - Recruiter Name: ${data.hrName || 'Hiring Manager'}
    - Interest: ${data.interest}
    
    Style Preferences:
    - Tone: ${data.tone}
    - Length: ${data.length}
    
    Please provide the response in JSON format with two keys: "subject" and "body".
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            subject: { type: Type.STRING },
            body: { type: Type.STRING }
          },
          required: ["subject", "body"]
        }
      }
    });

    const result = JSON.parse(response.text);
    return result;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to generate email. Please try again.");
  }
};
