
import React, { useState, useEffect } from 'react';
import { LandingPage } from './components/LandingPage.tsx';
import { AuthPage } from './components/AuthPage.tsx';
import { Dashboard } from './components/Dashboard.tsx';
import { AppView, GeneratedEmail } from './types.ts';
import { CheckCircle, Info, X } from 'lucide-react';

interface Toast {
  id: number;
  message: string;
  type: 'success' | 'info';
}

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('LANDING');
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);
  const [history, setHistory] = useState<GeneratedEmail[]>([]);
  const [toasts, setToasts] = useState<Toast[]>([]);

  useEffect(() => {
    const savedHistory = localStorage.getItem('intmail_history');
    if (savedHistory) setHistory(JSON.parse(savedHistory));
    
    const savedUser = localStorage.getItem('intmail_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
      setView('DASHBOARD');
    }
  }, []);

  const addToast = (message: string, type: 'success' | 'info' = 'success') => {
    const id = Date.now();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3000);
  };

  const saveHistory = (newHistory: GeneratedEmail[]) => {
    setHistory(newHistory);
    localStorage.setItem('intmail_history', JSON.stringify(newHistory));
  };

  const handleLogin = (email: string) => {
    const newUser = { name: email.split('@')[0], email };
    setUser(newUser);
    localStorage.setItem('intmail_user', JSON.stringify(newUser));
    setView('DASHBOARD');
    addToast('Successfully signed in');
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('intmail_user');
    setView('LANDING');
    addToast('Logged out successfully', 'info');
  };

  return (
    <div className="min-h-screen relative overflow-x-hidden">
      {/* Toast System */}
      <div className="fixed top-6 right-6 z-[100] space-y-3 pointer-events-none">
        {toasts.map((toast) => (
          <div 
            key={toast.id} 
            className="flex items-center gap-3 bg-white border border-gray-100 shadow-2xl p-4 rounded-2xl pointer-events-auto transform transition-all translate-x-0"
            style={{ animation: 'slideIn 0.3s ease-out forwards' }}
          >
            {toast.type === 'success' ? (
              <CheckCircle className="text-green-500 w-5 h-5" />
            ) : (
              <Info className="text-[#4F46E5] w-5 h-5" />
            )}
            <span className="font-medium text-[#0F172A]">{toast.message}</span>
            <button onClick={() => setToasts(t => t.filter(x => x.id !== toast.id))}>
              <X size={16} className="text-gray-400 hover:text-gray-600" />
            </button>
          </div>
        ))}
      </div>

      <style>{`
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
      `}</style>

      {view === 'LANDING' && <LandingPage onStart={() => setView('AUTH')} onLogin={() => setView('AUTH')} />}
      {view === 'AUTH' && <AuthPage onAuth={handleLogin} onBack={() => setView('LANDING')} />}
      {(['DASHBOARD', 'HISTORY', 'SAVED', 'PROFILE'].includes(view)) && (
        <Dashboard 
          view={view} 
          setView={setView} 
          user={user} 
          onLogout={handleLogout} 
          history={history} 
          setHistory={saveHistory}
          addToast={addToast}
        />
      )}
    </div>
  );
};

export default App;
