
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User, Contact, Template, GmailToken, Stats } from './types';
import Dashboard from './components/Dashboard';
import TemplateEditor from './components/TemplateEditor';
import UploadManager from './components/UploadManager';
import Settings from './components/Settings';
import QueueManager from './components/QueueManager';
import { processTemplate } from './utils/processor';

declare global {
  interface Window {
    google: any;
  }
}

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'template' | 'upload' | 'queue' | 'settings'>('dashboard');
  
  const [user, setUser] = useState<User>(() => {
    const saved = localStorage.getItem('ir_user');
    return saved ? JSON.parse(saved) : {
      id: '1',
      email: 'user@example.com',
      name: 'Alex Student',
      dailyLimit: 250 
    };
  });

  const [gmailStatus, setGmailStatus] = useState<GmailToken>(() => {
    const saved = localStorage.getItem('ir_gmail');
    return saved ? JSON.parse(saved) : { isConnected: false };
  });
  
  const [template, setTemplate] = useState<Template>(() => {
    const saved = localStorage.getItem('ir_template');
    return saved ? JSON.parse(saved) : {
      id: 't1',
      subject: 'Internship Opportunity at {{company_name}} - {{my_name}}',
      body: `Hi {{first_name}},\n\nI've been following {{company_name}} and I'm particularly impressed by {{company_highlight}}.\n\nI am writing to express my interest in a {{internship_type}} role. My background in {{my_strength}} makes me a strong fit for your team.\n\nBest,\n{{my_name}}`,
      globalVariables: {
        'my_name': 'Alex Student',
        'internship_type': 'Summer 2026 Software Engineering Intern',
        'my_strength': 'React development and data visualization'
      }
    };
  });

  const [contacts, setContacts] = useState<Contact[]>(() => {
    const saved = localStorage.getItem('ir_contacts');
    return saved ? JSON.parse(saved) : [];
  });

  const [isCampaignRunning, setIsCampaignRunning] = useState(false);
  const queueIntervalRef = useRef<number | null>(null);

  useEffect(() => { localStorage.setItem('ir_user', JSON.stringify(user)); }, [user]);
  useEffect(() => { localStorage.setItem('ir_gmail', JSON.stringify(gmailStatus)); }, [gmailStatus]);
  useEffect(() => { localStorage.setItem('ir_template', JSON.stringify(template)); }, [template]);
  useEffect(() => { localStorage.setItem('ir_contacts', JSON.stringify(contacts)); }, [contacts]);

  useEffect(() => {
    if (isCampaignRunning && gmailStatus.isConnected) {
      queueIntervalRef.current = window.setInterval(async () => {
        setContacts(prev => {
          const nextIdx = prev.findIndex(c => c.status === 'queued' || c.status === 'pending');
          if (nextIdx === -1) {
            setIsCampaignRunning(false);
            return prev;
          }
          const contact = prev[nextIdx];
          const newContacts = [...prev];
          newContacts[nextIdx] = { ...contact, status: 'sending' };
          handleSendEmail(contact.id);
          return newContacts;
        });
      }, 1000 + Math.random() * 500);
    } else {
      if (queueIntervalRef.current) {
        clearInterval(queueIntervalRef.current);
        queueIntervalRef.current = null;
      }
    }
    return () => { if (queueIntervalRef.current) clearInterval(queueIntervalRef.current); };
  }, [isCampaignRunning, gmailStatus.isConnected]);

  const handleSendEmail = async (contactId: string) => {
    const contact = contacts.find(c => c.id === contactId);
    if (!contact) return;
    try {
      const { subject, body } = await processTemplate(template, contact, user.name);
      await new Promise(r => setTimeout(r, 600)); 
      setContacts(prev => prev.map(c => 
        c.id === contactId 
          ? { ...c, status: 'sent', sentAt: new Date().toLocaleString(), renderedSubject: subject, renderedBody: body } 
          : c
      ));
    } catch (err) {
      setContacts(prev => prev.map(c => c.id === contactId ? { ...c, status: 'failed' } : c));
    }
  };

  const handleToggleCampaign = () => {
    if (!gmailStatus.isConnected) {
      alert("Please connect Gmail in Settings first.");
      setActiveTab('settings');
      return;
    }
    setIsCampaignRunning(!isCampaignRunning);
  };

  const handleConnectGmail = () => {
    if (!user.googleClientId) {
      alert("Provide a Google Client ID in Settings.");
      setActiveTab('settings');
      return;
    }
    try {
      const client = window.google.accounts.oauth2.initTokenClient({
        client_id: user.googleClientId,
        scope: 'https://www.googleapis.com/auth/gmail.send',
        callback: (response: any) => {
          if (response.access_token) {
            setGmailStatus({
              isConnected: true,
              email: user.email,
              accessToken: response.access_token,
              expiry: Date.now() + (response.expires_in * 1000)
            });
          }
        },
      });
      client.requestAccessToken();
    } catch (error) {
      alert("Auth Error.");
    }
  };

  const stats: Stats = {
    total: contacts.length,
    queued: contacts.filter(c => c.status === 'queued' || c.status === 'pending' || c.status === 'sending').length,
    sentToday: contacts.filter(c => c.status === 'sent').length,
    failed: contacts.filter(c => c.status === 'failed').length
  };

  return (
    <div className="flex min-h-screen bg-[#060b26]">
      {/* Vision UI Sidebar */}
      <aside className="w-72 hidden lg:flex flex-col p-6 vision-sidebar border-r border-white/5 fixed h-full z-50">
        <div className="flex items-center gap-3 px-3 mb-10">
          <div className="w-8 h-8 bg-cyan-500 rounded-lg flex items-center justify-center text-black font-black">I</div>
          <h1 className="text-sm font-black uppercase tracking-widest">Vision <span className="text-cyan-400">Reach</span></h1>
        </div>

        <nav className="space-y-2 flex-1">
          {(['dashboard', 'template', 'upload', 'queue', 'settings'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === tab 
                  ? 'active-nav' 
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span className={`w-5 h-5 flex items-center justify-center ${activeTab === tab ? 'neon-glow' : ''}`}>
                {tab === 'dashboard' && '📊'}
                {tab === 'template' && '📝'}
                {tab === 'upload' && '📂'}
                {tab === 'queue' && '🕒'}
                {tab === 'settings' && '⚙️'}
              </span>
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </nav>

        <div className="vision-card p-5 mt-auto bg-gradient-to-br from-indigo-600/20 to-cyan-600/20">
          <h4 className="text-[11px] font-black mb-1">PRO PLAN</h4>
          <p className="text-[10px] text-slate-400 mb-4 leading-relaxed">Unlock advanced AI deep research features.</p>
          <button className="w-full bg-white text-black py-2 rounded-lg text-[10px] font-black uppercase">Upgrade Now</button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 lg:ml-72 flex flex-col min-h-screen relative">
        <header className="sticky top-0 z-40 px-10 py-6 flex justify-between items-center bg-[#060b26]/80 backdrop-blur-md">
          <div className="text-xs font-bold text-slate-400">
            Pages / <span className="text-white capitalize">{activeTab}</span>
          </div>
          
          <div className="flex items-center gap-6">
            <div className={`flex items-center gap-2 text-[10px] font-black uppercase px-3 py-1.5 rounded-lg border ${gmailStatus.isConnected ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20' : 'bg-rose-500/10 text-rose-400 border-rose-500/20'}`}>
               <div className={`w-1.5 h-1.5 rounded-full ${gmailStatus.isConnected ? 'bg-cyan-400 animate-pulse' : 'bg-rose-400'}`}></div>
               {gmailStatus.isConnected ? 'Engine Live' : 'Offline'}
            </div>
            <div className="flex items-center gap-3">
               <span className="text-xs font-bold text-slate-400">{user.name}</span>
               <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-indigo-500 to-cyan-500 p-[1px]">
                  <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user.name}`} alt="avatar" className="w-full h-full rounded-full bg-[#060b26]" />
               </div>
            </div>
          </div>
        </header>

        <div className="px-10 pb-10 flex-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.3 }}
            >
              {activeTab === 'dashboard' && (
                <Dashboard 
                  stats={stats} 
                  contacts={contacts} 
                  isCampaignRunning={isCampaignRunning}
                  onToggleCampaign={handleToggleCampaign}
                  onNavigate={setActiveTab}
                  gmailStatus={gmailStatus}
                />
              )}
              {activeTab === 'template' && (
                <TemplateEditor 
                  template={template} 
                  onSave={setTemplate} 
                  contacts={contacts.slice(0, 3)}
                />
              )}
              {activeTab === 'upload' && (
                <UploadManager 
                  onUpload={setContacts} 
                  existingContacts={contacts}
                  user={user}
                  onUserUpdate={setUser}
                />
              )}
              {activeTab === 'queue' && (
                <QueueManager 
                  contacts={contacts} 
                />
              )}
              {activeTab === 'settings' && (
                <Settings 
                  user={user} 
                  onUserUpdate={setUser}
                  gmailStatus={gmailStatus}
                  onConnectGmail={handleConnectGmail}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
};

export default App;
