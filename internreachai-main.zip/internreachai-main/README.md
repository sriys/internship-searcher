<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://drive.google.com/thumbnail?id=1kIHaMg6ezb3AePPz35hwYKXNKIrdYIAP&sz=w1200" />
</div>
https://drive.google.com/file/d/1kIHaMg6ezb3AePPz35hwYKXNKIrdYIAP/view?usp=sharing
# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/drive/1A5MD1FspaPlEEEhp4dDaOlgohjX7a1tl

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`
