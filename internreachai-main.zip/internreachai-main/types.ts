
export interface User {
  id: string;
  email: string;
  name: string;
  openaiKey?: string;
  googleClientId?: string;
  resumeFile?: string;
  resumeName?: string;
  dailyLimit: number;
}

export interface GmailToken {
  isConnected: boolean;
  email?: string;
  accessToken?: string;
  expiry?: number;
}

export interface Contact {
  id: string;
  name: string;
  email: string;
  company: string;
  status: 'pending' | 'queued' | 'sending' | 'sent' | 'failed' | 'opted-out';
  variables: Record<string, string>;
  plannedSendAt?: string;
  sentAt?: string;
  renderedSubject?: string;
  renderedBody?: string;
}

export interface Template {
  id: string;
  subject: string;
  body: string;
  globalVariables: Record<string, string>;
}

export interface Stats {
  total: number;
  queued: number;
  sentToday: number;
  failed: number;
}
